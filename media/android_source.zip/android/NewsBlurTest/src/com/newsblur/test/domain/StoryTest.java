package com.newsblur.test.domain;

public class StoryTest {

}

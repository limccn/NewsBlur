package com.slickreader.util;

public interface ReadFilterChangedListener {
  void readFilterChanged(ReadFilter newValue);
}

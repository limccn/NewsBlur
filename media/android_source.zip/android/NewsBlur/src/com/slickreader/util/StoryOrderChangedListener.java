package com.slickreader.util;

public interface StoryOrderChangedListener {
    void storyOrderChanged(StoryOrder newValue);
}

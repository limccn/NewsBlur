package com.slickreader.activity;


public class FeedSearch extends NbFragmentActivity {

}

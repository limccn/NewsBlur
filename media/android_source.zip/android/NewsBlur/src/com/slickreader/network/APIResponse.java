package com.slickreader.network;

public class APIResponse {
	
	public String responseString = "";
	public int responseCode = -1;
	public boolean hasRedirected;
	public boolean isOffline;
	public String cookie;

}

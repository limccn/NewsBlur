@interface TransparentToolbar : UIToolbar
@end
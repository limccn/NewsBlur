/* Copyright 2012 IGN Entertainment, Inc. */

#import <Foundation/Foundation.h>
#import "ShareThis.h"

extern NSString *const SafariActivity;

@interface SafariService : NSObject <STService>

@end

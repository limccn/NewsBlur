/* Copyright 2012 IGN Entertainment, Inc. */

#import <Foundation/Foundation.h>
#import "ShareThis.h"
#import "MessageUI/MessageUI.h"

@interface MessageService : NSObject <STService, MFMessageComposeViewControllerDelegate>

@end

/* Copyright 2012 IGN Entertainment, Inc. */

#import <Foundation/Foundation.h>
#import "ShareThis.h"
#import "ReadLaterService.h"

extern NSString *const PocketActivity;

@interface PocketService : ReadLaterService <STService>

@end

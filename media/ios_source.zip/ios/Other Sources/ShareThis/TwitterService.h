/* Copyright 2012 IGN Entertainment, Inc. */

#import <Foundation/Foundation.h>
#import "ShareThis.h"
@interface TwitterService : NSObject <STService>

@end

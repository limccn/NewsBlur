/* Copyright 2012 IGN Entertainment, Inc. */

#import <UIKit/UIKit.h>

@interface SafariActivityItem : UIActivity

@end

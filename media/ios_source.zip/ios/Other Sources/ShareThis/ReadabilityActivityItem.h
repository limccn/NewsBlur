/* Copyright 2012 IGN Entertainment, Inc. */

#import <UIKit/UIKit.h>

@interface ReadabilityActivityItem : UIActivity

@end

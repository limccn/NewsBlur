/* Copyright 2012 IGN Entertainment, Inc. */

#import <Foundation/Foundation.h>
#import "ShareThis.h"
#import "ReadLaterService.h"

extern NSString *const ReadabilityActivity;

@interface ReadabilityService : ReadLaterService <STService>

@end

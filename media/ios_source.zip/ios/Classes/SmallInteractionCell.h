//
//  SmallInteractionCell.h
//  NewsBlur
//
//  Created by Samuel Clay on 2/21/13.
//  Copyright (c) 2013 NewsBlur. All rights reserved.
//

#import "InteractionCell.h"

@interface SmallInteractionCell : InteractionCell

@end

//
//  SmallActivityCell.h
//  NewsBlur
//
//  Created by Roy Yang on 7/21/12.
//  Copyright (c) 2012 NewsBlur. All rights reserved.
//

#import "ActivityCell.h"

@interface SmallActivityCell : ActivityCell

@end
